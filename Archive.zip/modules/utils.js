function getDate() {
    return new Date().toString();
}

module.exports = { getDate };